package DDFW;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class data_pro_login_xl extends excel_logindata {
		data_pro_login test;
	@BeforeClass	
		public void get_data() {
			get_test_data();
			
		}
		
	  @Test(dataProvider = "login_data")
	  public void login(String eid, String pwd,String expid) {
		  test = new data_pro_login();
		  String actid= test.login(eid, pwd);
		  SoftAssert sa= new SoftAssert();
		  sa.assertEquals(actid,expid);
		  sa.assertAll();
		  System.out.println("email :"+eid+"  pwd: "+pwd);
	  }

	  @DataProvider(name="login_data")
	  public String[][] dp() {
		 
		  
		  return testdata;
  }
}
