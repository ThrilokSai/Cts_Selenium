package excel_operations;



public class write_excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_operations excel=new excel_operations();
		String data=excel.read_excel(3,0);
		System.out.println("Data: "+data);
		excel.write_excel3(3,0,"excel");
		excel.write_excel2(2,0,"excel");
		excel.write_excel1(1,0,"excel");
	}

}
