package TSEST_RUNNER;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

public class NewTest {
  @CucumberOptions(features="FEATURES", glue="STEP_DEF")
 public class testrunner1 extends AbstractTestNGCucumberTests{
	  
  }}
