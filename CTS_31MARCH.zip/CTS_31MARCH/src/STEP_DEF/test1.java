package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class test1  {
	
	public static WebDriver dr;
	
	
	
	@Given("^Login Page is displayed$")
	public void login_Page_is_displayed() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
		 dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.className("ico-login")).click();
		
		
	}
	
	@When("^User enters login data and clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button() throws Throwable {
		
		dr.findElement(By.className("email")).sendKeys("ex1@gmail.com");
		dr.findElement(By.className("password")).sendKeys("12345678");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    
	}
	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	   String act=dr.findElement(By.className("account")).getText();
		String exp="ex1@gmail.com";
		SoftAssert sa= new SoftAssert();
		sa.assertEquals(act, exp);
		sa.assertAll();
	    
	}
	
	
	@When("^User enters invalid emailid and clicks ok button$")
	public void user_enters_invalid_emailid_and_clicks_ok_button() throws Throwable {
		dr.findElement(By.className("email")).sendKeys("ex2@gmail.com");
		dr.findElement(By.className("password")).sendKeys("12345678");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

	}

	@Then("^Error message should be displayed:account not found$")
	public void error_message_should_be_displayed_account_not_found() throws Throwable {
		
		 String act=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		String exp="No customer account found";
		SoftAssert sa= new SoftAssert();
		sa.assertEquals(act, exp);
		sa.assertAll();
	   
	
	
	}
	

	}
