 package com.tests;

import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.excelop.excel_logindata;
import com.pages.productspage;
import com.pages.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class Tests extends excel_logindata {
	WebDriver dr;
	loginPage lp;
	productspage hp;
 /*@Test
  public void test2() {
	  lp.do_login("standard_user","secret_sauce");
	  //dr.navigate().back();
  }*/
  
  @Test
  public void title() {
	 
	  String actual= lp.title();
	  String expected="Swag Labs";
		Assert.assertEquals(actual, expected);
	   
  }
  
  @Test(dataProvider = "login_data")
  public void textcheck(String uname, String pwd,String exp) {
	  lp.do_login(uname,pwd);
	  String actual=hp.check();
	 // String expected="Products";
	  System.out.println(actual);
		Assert.assertEquals(actual, exp);  
 }
  @BeforeClass
  public void launchbrowser1()
  	{
	 /*//dr=utilities.launch_Browser("chrome", "https://www.saucedemo.com/");
	 lp=new loginPage(dr);
	hp=new homePage(dr)	;*/
	get_test_data();
	
	System.out.println(testdata);
	}
 @BeforeMethod
  public void launchbrowser()
  	{
	 dr=utilities.launch_Browser("chrome", "https://www.saucedemo.com/");
	 lp=new loginPage(dr);
	hp=new productspage(dr)	;
	//get_test_data();
	
	}
 
  @DataProvider(name="login_data")
  public String[][] dp() {
	 
	  
	  return testdata;
	  
}
  @AfterClass
  public void closebrowser() {
	  dr.close();
  }
}
