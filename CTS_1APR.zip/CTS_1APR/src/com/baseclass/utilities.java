package com.baseclass;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class utilities {

	static int counter=1;
	WebDriver dr;
	Logger log;
	public utilities(WebDriver dr) {
		this.dr=dr;
		log=Logger.getLogger("devpino/Logger");
	}
	
	
	public static WebDriver launch_Browser(String browser,String url) {
		
	WebDriver dr=null;
	String ch_driver_path="C:/Users/3lok/Desktop/java/chromedriver.exe";
	//String ff_driver_path="C:/Users/3lok/Desktop/java/chromedriver.exe";	
	switch(browser) {
	case "chrome":
		 System.setProperty("webdriver.chrome.driver", ch_driver_path);
			dr=new ChromeDriver();
			break;
	/*case "firefox":
		 System.setProperty("webdriver.firefox.driver",ff_driver_path);
			dr=new FirefoxDriver();
			break;*/
	default:
		System.out.println("Support browser options: chrome and firefox");
		break;
		
	}
	dr.get(url);
	dr.manage().window().maximize();
	dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	return dr;
	}
	
}
