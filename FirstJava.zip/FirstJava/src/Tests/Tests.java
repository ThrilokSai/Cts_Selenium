package Tests;

import org.testng.annotations.Test;

import pages.homePage;
import pages.loginPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class Tests {
	WebDriver dr;
	homePage hp;
	loginPage lp;
	

  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
	  dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com");
	  hp= new homePage(dr);
	  lp= new loginPage(dr);
	  
  }
  @Test
  public void loginTest() {
	  hp.click_login();
	  lp.do_login("ex1@gmail.com", "12345678");
	  }
  /*@Test
  public void logout() {
	  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	  }*/

}
