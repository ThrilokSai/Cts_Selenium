package pages2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class homePage {
	WebDriver dr2;
	

	
	public homePage(WebDriver dr)
	{
		dr2=dr;
	}
	
public String check() {
	String actual=dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	return actual;
}


}



