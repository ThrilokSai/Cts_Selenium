package com.sel;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class dataProvider {
	
  @Test(dataProvider = "login_data")
  public void login(String eid, String pwd) {
	  System.out.println("email :"+eid+"  pwd: "+pwd);
  }

  @DataProvider(name="login_data")
  public String[][] dp() {
    String[][] data={
       { "e1", "p1" },
      { "e2", "p2" },
    };return data;
  }
}
