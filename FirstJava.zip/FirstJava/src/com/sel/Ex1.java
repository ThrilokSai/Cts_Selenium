   package com.sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com");
		String expectedTitle="Demo Web Shop";
		String actualTitle=driver.getTitle();
		if(actualTitle.contentEquals(expectedTitle)) 
		{
			driver.findElement(By.className("ico-login")).click();
			driver.findElement(By.className("email")).sendKeys("ex1@gmail.com");
			String a=driver.findElement(By.className("email")).getAttribute("value");
		 	//System.out.println(a);
			driver.findElement(By.className("password")).sendKeys("12345678");
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			
			String b=driver.findElement(By.className("account")).getText();
			if(a.equals(b))
				System.out.println("pass");
			else
				System.out.println("fail");
		}driver.close();
	}

}
