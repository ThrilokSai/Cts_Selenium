package com.sel;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Testng {
	
	
	
	
  @Test
  public void test1() {
 
  String actual;
  String exp="ex1@gmail.com";
  loginTest demoweb= new loginTest();
  actual= demoweb.login();
  Assert.assertEquals(actual, exp);
  
  }
}
