package com.sel;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SelDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.testandquiz.com/selenium/testing.html");
		driver.get("https://www.facebook.com");
		/*String a=driver.getTitle();
		String b="Google";
		System.out.println(driver.getTitle());
		if(a.contentEquals(b))
			System.out.println("pass");
		String c=driver.findElement(By.className("gb_g")).getTagName();
		//System.out.println(c);
		//System.out.println(driver.getPageSource());
		//String d=driver.findElement(By.className("gb_g")).getText();
		//System.out.println(d);
		driver.navigate().refresh();//to("www.facebook.com");
*/		/*WebElement element = driver.findElement(By.name("source"));  
   		WebElement target = driver.findElement(By.name("target"));  
  
   		new Actions(driver).dragAndDrop(element, target).perform();  */
		//new Actions(driver).
   		//WebElement testDropDown = driver.findElement(By.id("testingDropdown"));  
   		Select dropdown = new Select(driver.findElement(By.id("month")));  
   		
   		dropdown.selectByValue("9");
   	 JavascriptExecutor js = (JavascriptExecutor)driver;  
     js.executeScript("scrollBy(0, 4500)");
	

}
}