package tests2;

import org.testng.annotations.Test;

import pages2.homePage;
import pages2.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class Tests {
	WebDriver dr;
	loginPage lp;
	homePage hp;
 @Test
  public void test2() {
	  lp.do_login("standard_user","secret_sauce");
	  // dr.navigate().back();
  }
  
  @Test
  public void test1() {
	 
	  String actual= lp.title();
	  String expected="Swag Labs";
		Assert.assertEquals(actual, expected);
	   
  }
  
  @Test
  public void test3() {
	  //lp.do_login("standard_user","secret_sauce");
	  String actual=hp.check();
	  String expected="Products";
	  System.out.println(actual);
		Assert.assertEquals(actual, expected);  
  }
	   
  
  
  @BeforeClass
  public void launchbrowser()
  	{
	  System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
	  dr=new ChromeDriver();
	  dr.get("https://www.saucedemo.com/");
	 lp=new loginPage(dr);
	hp=new homePage(dr)	;
	}

}
