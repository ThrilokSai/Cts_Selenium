package DDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basic_login {
	
	public  String login(String uname,String pwd) {
		

		System.setProperty("webdriver.chrome.driver", "C:/Users/3lok/Desktop/java/chromedriver.exe");
		WebDriver dr =new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[1]")).sendKeys(uname);
		dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[2]")).sendKeys(pwd);
		dr.findElement(By.xpath("//*[@id=\"login\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[3]")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/table/tbody/tr[1]/td[2]/span")).getText();
		//dr.findElement(By.xpath("//*[@id="+"MenuContent"+"]/a[2]"));
		//dr.findElement(By.linkText("Sign Out")).click();;
		dr.close();
		return s;
		
	}
	
	
	
	
	
}
