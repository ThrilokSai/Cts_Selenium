package DDFW;

public class test extends basic_login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		basic_login n= new basic_login();
		System.out.println(n.login("ctsdemo", "12345678"));
		
	}

}
