package DDFW;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class dataprov_loginxl extends excel_data {
	basic_login testing;
	@BeforeClass
	public void get() {
	get_data();
	}	
  @Test(dataProvider = "login data")
  
  public void login(String  uname, String pwd,String exp) {
	  testing = new basic_login();
	  String act=testing.login(uname, pwd);
	 //String expected= exp;
	  Assert.assertEquals(act, exp);	  
  }

  @DataProvider(name="login data")
  public String[][] dp() {
    return  testdata;
    }
  }

