package excel_operations;

public class excel_call {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;//j=0;
		int j=0;
		excel_operations excel=new excel_operations();
		test demo=new test();
		
		for(i=0;i<7;i++)
		{
			for(j=0;j<=5;j++)
			{
				String a=excel.read_excel(i, j) ;
				excel.write_excel(i, j,a);
				/*String b=demo.read_excel(i, j) ;
				demo.write_excel(i, j,b);
				//System.out.println(b);
*/				
	}

}}}
