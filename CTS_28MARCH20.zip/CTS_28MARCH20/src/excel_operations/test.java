package excel_operations;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class test {
	
	public String read_excel(int row,int col) {
		String filename="C:\\Users\\3lok\\Desktop\\java\\KWDFW_FILE.xlsx",sheetname="KEYWORD";
		String  s=null;
		try {
		File f= new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(sheetname);
		XSSFRow r= sh.getRow(row);
		XSSFCell c=r.getCell(col);
		s=c.getStringCellValue();
		System.out.println(s);
		//write_excel(row, col, s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return s;
		}
	
	public void write_excel(int row ,int col,String data) {
		String filename="C:/Users/3lok/Desktop/java/write_excel.xlsx",sheetname="Sheet2";
		try {
			File f=new File(filename);
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet(sheetname);
			
			XSSFRow r=sh.createRow(row);
			XSSFCell c=r.createCell(col);
			//System.out.println(data);
			c.setCellValue(data);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
