package com.tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.pages.cart_page;
import com.pages.loginPage;
import com.pages.productspage;

public class testcart {
	WebDriver dr;
	cart_page cp;
	loginPage lp;
	productspage hp;
	String uname="standard_user", pwd="secret_sauce";
	
	
  @Test
  public void name_check() {
	  lp.do_login(uname, pwd);
	  String expected= hp.get_name();
	  hp.add_cart();
	  String actual=cp.get_name();
	  Assert.assertEquals(actual, expected);
	  System.out.println("in name");
  }
 @Test
  public void price_check() {
	  lp.do_login(uname, pwd);
	  String expected= hp.get_price();
	  hp.add_cart();
	  String actual=cp.get_price();
	  Assert.assertEquals(actual, expected);
	  System.out.println("in pice");
  }
  
  @BeforeMethod
  public void launchbrowser(){
	  dr=utilities.launch_Browser("chrome", "https://www.saucedemo.com/");
		 lp=new loginPage(dr);
		 hp=new productspage(dr);	
		 cp= new cart_page(dr);
	  
  }
  
  
}
