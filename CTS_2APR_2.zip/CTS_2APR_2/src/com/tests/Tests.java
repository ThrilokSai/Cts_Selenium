 package com.tests;

import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.excelop.excel_logindata;
import com.pages.productspage;
import com.pages.cart_page;
import com.pages.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class Tests extends excel_logindata {
	WebDriver dr;
	loginPage lp;
	productspage hp;
	cart_page cp;
	String uname="standard_user", pwd="secret_sauce", exp="Products";
  

  @Test
   public void textcheck() {
	  lp.do_login(uname,pwd);
	  String actual=hp.check();
	  System.out.println(actual);
	  Assert.assertEquals(actual, exp);  
	 // hp.add_cart();
	  System.out.println("in check");
 }
 
 @BeforeSuite
  public void launchbrowser()
  	{
	 dr=utilities.launch_Browser("firefox", "https://www.saucedemo.com/");
	 lp=new loginPage(dr);
	 hp=new productspage(dr)	;
	 cp= new cart_page(dr);
	}
 

}
