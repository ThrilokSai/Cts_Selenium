package com.tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.pages.cart_page;
import com.pages.loginPage;
import com.pages.productspage;

public class dem extends Tests{
	
  @Test
  public void namecheck() {
	  //lp.do_login(uname, pwd);
	  String expname= hp.get_name();
	  String expeprc= hp.get_price();
	  hp.add_cart();
	  String actualname=cp.get_name();
	  String actualprice=cp.get_price();
	  Assert.assertEquals(actualname, expname);
	  Assert.assertEquals(actualprice, expeprc);
	  System.out.println("in name");
  }
  /*@BeforeMethod
  public void launchbrowser(){
	  dr=utilities.launch_Browser("chrome", "https://www.saucedemo.com/");
		 lp=new loginPage(dr);
		 hp=new productspage(dr);	
		 cp= new cart_page(dr);
	  
  }*/
}
