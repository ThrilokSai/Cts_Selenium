package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class productspage {
	WebDriver dr2;
	By name=By.xpath("//*[@id=\"item_4_title_link\"]/div");
	//By price=By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/div/text()[2]");
	By price=By.className("inventory_item_price");
	By add_btn= By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
	
	public productspage(WebDriver dr)
	{
		dr2=dr;
	}
	
	public String check() {
	String actual=dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	//System.out.println(actual);
	//dr2.close();
	return actual;
}

public void add_cart() {
	dr2.findElement(add_btn).click();
	//dr2.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/svg")).click();
	dr2.findElement(By.id("shopping_cart_container")).click();
}


public String get_name() {
	String exp_name=dr2.findElement(name).getText();
	return exp_name;
	
}
public String get_price() {
	String exp_price=dr2.findElement(price).getText();
	System.out.println(exp_price);
	return exp_price;
}





}



