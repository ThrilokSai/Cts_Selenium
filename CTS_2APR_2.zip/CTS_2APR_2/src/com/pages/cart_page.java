package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cart_page {
	WebDriver dr3;
	
	public cart_page(WebDriver dr) {
		this.dr3=dr;
	}
	
	By add_btn= By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
	By name=By.xpath("//*[@id=\"item_4_title_link\"]/div");
	By price=By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div");
	
	public void price_check() {
		dr3.findElement(add_btn).click();
	}
	
	public String get_name() {
		String act_name=dr3.findElement(name).getText();
		return act_name;
	}
	public String get_price() {
		String act_price=dr3.findElement(price).getText();
		String price= "$"+act_price;
		System.out.println(price);
		return price;
	}
	
	
}
